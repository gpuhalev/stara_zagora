<!DOCTYPE html> 
<html>

<head>
  <?php 
    include 'header.html';
  ?>
  <title>Travel | European Athletics Team Championships 2nd League Stara Zagora 2015</title>  
</head>

<body>
    <?php 
      include 'menu.html';
    ?>
	  <div id="content">
        <div class="content_item">
		  <h1>Travel</h1> 
          
		</div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
  </div><!--close main-->
  
    <?php 
      include 'footer.html';
    ?>


  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  
</body>
</html>
